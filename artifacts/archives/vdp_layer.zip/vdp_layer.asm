; ═══════════════════════════════════════════════════════════════
; vdp_layer.asm - Sega Genesis VDP Hardware Layer
; Phase 2: NES PPU → Genesis VDP translation
;
; NES PPU registers mapped to Genesis VDP:
;   $2000 = PPUCTRL   → VDP reg $80/$81 (control)
;   $2001 = PPUMASK   → VDP reg $81 (enable/disable rendering)
;   $2002 = PPUSTATUS → Read VDP status port (vblank flag)
;   $2003 = OAMADDR   → Sprite table address (handled via DMA)
;   $2004 = OAMDATA   → Sprite data write
;   $2005 = PPUSCROLL → VDP horizontal/vertical scroll
;   $2006 = PPUADDR   → VDP VRAM address register
;   $2007 = PPUDATA   → VDP VRAM data port
;
; Genesis VDP ports:
;   $C00000 = VDP Data port  (read/write VRAM data)
;   $C00002 = VDP Data port  (mirror)
;   $C00004 = VDP Control port (write commands, read status)
;   $C00006 = VDP Control port (mirror)
;   $C00008 = HV Counter
;
; Genesis VDP register write format:
;   Write word to control port: $8000 | (reg_num << 8) | value
;   e.g. write $04 to VDP reg $01: write $8104 to $C00004
;
; VRAM write address format:
;   Two writes to control port:
;   First:  $4000 | (addr >> 14) | ((addr >> 2) & $3FFF) ... actually:
;   Simpler: (($4000 | (vram_addr & $3FFF)) << 16) | ($00 | (vram_addr >> 14))
; ═══════════════════════════════════════════════════════════════

; ── Genesis VDP Port Addresses ──
VDP_DATA        EQU $C00000     ; VRAM data read/write
VDP_CTRL        EQU $C00004     ; VDP control / status
VDP_HVCOUNTER   EQU $C00008     ; H/V counter

; ── VDP Register Numbers ──
VDP_REG_MODE1   EQU $80         ; Mode register 1 ($80 = reg 0)
VDP_REG_MODE2   EQU $81         ; Mode register 2 ($81 = reg 1)  ← enable display
VDP_REG_PLANE_A EQU $82         ; Plane A name table addr
VDP_REG_WINDOW  EQU $83         ; Window name table addr
VDP_REG_PLANE_B EQU $84         ; Plane B name table addr
VDP_REG_SPRITE  EQU $85         ; Sprite table addr
VDP_REG_BGCOLOR EQU $87         ; Background color
VDP_REG_HSCROLL EQU $8D         ; H scroll data addr
VDP_REG_AUTOINC EQU $8F         ; Auto-increment value
VDP_REG_SCROLL  EQU $90         ; Scroll size
VDP_REG_WINHPOS EQU $91         ; Window H position
VDP_REG_WINVPOS EQU $92         ; Window V position
VDP_REG_DMALENC EQU $93         ; DMA length counter low
VDP_REG_DMALENB EQU $94         ; DMA length counter high
VDP_REG_DMASRC1 EQU $95         ; DMA source addr low
VDP_REG_DMASRC2 EQU $96         ; DMA source addr mid
VDP_REG_DMASRC3 EQU $97         ; DMA source addr high + type

; ── NES color palette → Genesis CRAM mapping ──
; NES uses 64 color palette, Genesis uses 4 palettes of 16 colors (BGR555)
; Palette 0 maps to Genesis palette 0, etc.
NES_PAL_VRAM    EQU $3F00       ; NES palette VRAM address
GEN_CRAM_BASE   EQU $C000       ; Genesis CRAM write command base

; ── Internal state variables (in Genesis RAM) ──
; We keep shadow copies of PPU state since Genesis VDP is write-only
; VDP shadow regs placed at $FFEF00-$FFEF0A (top of RAM, above Zelda data)
; Zelda uses $FF0000-$FF07FF; stack grows down from $FFFE00.
; $FFEF00 is safely between them and is NOT cleared by clear_memory.
VDP_SHADOW_BASE EQU $FFFFEF00   ; VDP shadow regs base (24-bit addr: $FFEF00)
PPUCTRL_SHADOW  EQU $FFFFEF00   ; Shadow of NES $2000
PPUMASK_SHADOW  EQU $FFFFEF01   ; Shadow of NES $2001
PPUADDR_HI      EQU $FFFFEF02   ; High byte of VRAM address latch
PPUADDR_LO      EQU $FFFFEF03   ; Low byte of VRAM address latch
PPUADDR_LATCH   EQU $FFFFEF04   ; 0=expect hi byte, 1=expect lo byte
PPUSCROLL_X     EQU $FFFFEF05   ; Horizontal scroll shadow
PPUSCROLL_Y     EQU $FFFFEF06   ; Vertical scroll shadow
PPUSCROLL_LATCH EQU $FFFFEF07   ; 0=expect X, 1=expect Y
VRAM_ADDR_CURR  EQU $FFFFEF08   ; Current VRAM address (word)
VDP_REG1_SHADOW EQU $FFFFEF0A   ; Shadow of VDP mode reg 2 (display+vblank bits)

; ═══════════════════════════════════════════════════════════════
; VDP_INIT - Call once at startup instead of NES PPU init
; Replaces the NES reset handler PPU initialization sequence
; ═══════════════════════════════════════════════════════════════
VDP_INIT:
    ; Wait for VDP to be ready
    move.w  #$8000,($C00004)    ; Disable display during init (mode reg 1)
    move.w  #$8134,($C00004)    ; Mode reg 2: enable VDP, PAL/NTSC
                                 ; $8134 = reg1, enable display+vint, 28 cell

    ; Set up name tables
    move.w  #$8230,($C00004)    ; Plane A at VRAM $C000 (reg2, $30 = $C000>>10)
    move.w  #$8307,($C00004)    ; Window  at VRAM $E000 (reg3)
    move.w  #$8407,($C00004)    ; Plane B at VRAM $E000 (reg4)
    move.w  #$856C,($C00004)    ; Sprite table at $D800  (reg5, $6C = $D800>>9)

    ; Colors / scroll
    move.w  #$8700,($C00004)    ; BG color = palette 0, color 0
    move.w  #$8B00,($C00004)    ; No external interrupt (reg11)
    move.w  #$8C81,($C00004)    ; H40 mode (320px wide) (reg12)
    move.w  #$8D2F,($C00004)    ; HScroll table at $BC00 (reg13)
    move.w  #$8F02,($C00004)    ; Auto-increment = 2 bytes (reg15)
    move.w  #$9001,($C00004)    ; Scroll size 64x32 cells (reg16)
    move.w  #$9100,($C00004)    ; Window H pos = 0 (reg17)
    move.w  #$9200,($C00004)    ; Window V pos = 0 (reg18)

    ; Clear VRAM
    bsr     VDP_CLEAR_VRAM

    ; Load NES color palette approximations into CRAM
    bsr     VDP_LOAD_NES_PALETTE

    ; Init shadow registers
    clr.b   (PPUCTRL_SHADOW).l
    clr.b   (PPUMASK_SHADOW).l
    clr.b   (PPUADDR_LATCH).l
    clr.b   (PPUSCROLL_LATCH).l
    clr.w   (VRAM_ADDR_CURR).l

    ; Enable display - initialize shadow register
    ; NOTE: VINT intentionally NOT enabled here. Game code enables it explicitly
    ; via PPU_WRITE_2000($A0) at loc_E440 AFTER ram_for_2000 is initialized.
    ; Pre-enabling VINT here causes NMI to fire before ram_for_2000=$A0 is set.
    move.b  #$74,(VDP_REG1_SHADOW).l  ; display ON, vblank IRQ ON
    move.w  #$8174,($C00004)           ; Mode reg 2: enable display + VINT
    rts

; ═══════════════════════════════════════════════════════════════
; PPU_WRITE_2000 - Replaces: MOVE.B Dn, PPU_REG_$2000
; NES PPUCTRL: NMI enable, sprite size, pattern table selects etc.
; D0 = value to write
; ═══════════════════════════════════════════════════════════════
PPU_WRITE_2000:
    move.b  D0,(PPUCTRL_SHADOW).l   ; save shadow copy

    ; Bit 7 = NMI enable → controls vblank IRQ (reg1 bit 5)
    ; Read shadow, set/clear bit 5 only, preserve display bit 6
    move.b  (VDP_REG1_SHADOW).l,D3
    btst    #7,D0
    beq     .disable_vint
    ori.b   #$20,D3
    bra     .apply_reg1
.disable_vint:
    andi.b  #$DF,D3
.apply_reg1:
    move.b  D3,(VDP_REG1_SHADOW).l
    move.w  #$8100,D4
    or.b    D3,D4
    move.w  D4,($C00004)
.done_2000:
    rts

; ═══════════════════════════════════════════════════════════════
; PPU_WRITE_2001 - Replaces: MOVE.B Dn, PPU_REG_$2001
; NES PPUMASK: show/hide background, sprites, left-column clipping
; D0 = value to write
; ═══════════════════════════════════════════════════════════════
PPU_WRITE_2001:
    move.b  D0,(PPUMASK_SHADOW).l

    ; Bits 3+4 = show background + show sprites → display enable (reg1 bit 6)
    ; Use shadow register to preserve vblank IRQ bit independently
    move.b  (VDP_REG1_SHADOW).l,D3
    move.b  D0,D4
    andi.b  #$18,D4
    beq     .disable_display
    ori.b   #$40,D3                 ; set bit 6 (display on)
    bra     .apply_reg1_2001
.disable_display:
    andi.b  #$BF,D3                 ; clear bit 6 (display off)
.apply_reg1_2001:
    move.b  D3,(VDP_REG1_SHADOW).l
    move.w  #$8100,D4
    or.b    D3,D4
    move.w  D4,($C00004)
.done_2001:
    rts

; ═══════════════════════════════════════════════════════════════
; PPU_READ_2002 - Replaces: MOVE.B PPU_REG_$2002, Dn
; NES PPUSTATUS: vblank flag (bit 7), sprite 0 hit (bit 6)
; Returns result in D0
; Also resets the address latch ($2005/$2006)
; ═══════════════════════════════════════════════════════════════
PPU_READ_2002:
    ; Read Genesis VDP status register
    move.w  ($C00004),D0            ; read VDP status word
    ; Genesis status word (16-bit):
    ;   bit 9 = VBLANK active (in vertical blank interval) ← this is what we want
    ;   bit 8 = HBLANK active
    ;   bit 7 = DMA Busy (NOT vblank - previous patch #11 was wrong about bit7)
    ;   bit 2 = Sprite Collision
    ; NES status:     bit 7 = vblank, bit 6 = sprite 0 hit
    ; Remap bits:
    move.w  D0,D3
    clr.b   D0
    btst    #9,D3                   ; Genesis vblank = bit9 of status word (bit7 is DMA busy, not vblank)
    beq     .no_vblank
    bset    #7,D0                   ; set NES-style vblank bit 7
.no_vblank:
    ; Do not synthesize NES sprite-0-hit from Genesis sprite collision here.
    ; False positives poison Zelda startup/title $2002 polling.
    ; Reset address latches (reading $2002 resets them on NES)
    clr.b   (PPUADDR_LATCH).l
    clr.b   (PPUSCROLL_LATCH).l
    rts

; ═══════════════════════════════════════════════════════════════
; PPU_WRITE_2003 - Replaces: MOVE.B Dn, PPU_REG_$2003
; NES OAMADDR: set OAM (sprite RAM) address
; On Genesis, sprite data is in VRAM at the sprite table address
; D0 = OAM address
; ═══════════════════════════════════════════════════════════════
PPU_WRITE_2003:
    ; Store OAM address - used when $2004 writes follow
    ; Genesis handles sprites differently (VRAM-based)
    ; For now, store it for use by DMA sprite transfer
    move.b  D0,($FFFFEF09).l        ; OAM address shadow
    rts

; ═══════════════════════════════════════════════════════════════
; PPU_WRITE_2005 - Replaces: MOVE.B Dn, PPU_REG_$2005
; NES PPUSCROLL: two writes set X then Y scroll
; D0 = scroll value
; ═══════════════════════════════════════════════════════════════
PPU_WRITE_2005:
    tst.b   (PPUSCROLL_LATCH).l
    bne     .write_y
    ; First write = X scroll
    move.b  D0,(PPUSCROLL_X).l
    ; Write to Genesis HScroll VRAM
    ; HScroll table at $BC00, format: word per row, negative value = scroll right
    move.l  #$BC000003,($C00004)    ; set VRAM write addr to HScroll table
    move.w  D0,D3
    neg.w   D3                      ; Genesis scrolls opposite direction
    move.w  D3,($C00000)            ; write scroll value
    move.b  #1,(PPUSCROLL_LATCH).l
    rts
.write_y:
    ; Second write = Y scroll
    move.b  D0,(PPUSCROLL_Y).l
    ; Write to Genesis VSRAM (vertical scroll RAM)
    ; VSRAM write command: 0x40004000 | (byte_offset << 16)  for offset 0
    move.l  #$40004000,($C00004)    ; VSRAM write address 0 (BUG A fix: was $40000010)
    move.w  D0,($C00000)            ; write Y scroll
    clr.b   (PPUSCROLL_LATCH).l
    rts

; ═══════════════════════════════════════════════════════════════
; PPU_WRITE_2006 - Replaces: MOVE.B Dn, PPU_REG_$2006
; NES PPUADDR: two writes set high then low byte of VRAM address
; D0 = address byte
; ═══════════════════════════════════════════════════════════════
PPU_WRITE_2006:
    tst.b   (PPUADDR_LATCH).l
    bne     .write_lo
    ; First write = high byte
    move.b  D0,(PPUADDR_HI).l
    move.b  #1,(PPUADDR_LATCH).l
    rts
.write_lo:
    ; Second write = low byte - now set the full VRAM address
    move.b  D0,(PPUADDR_LO).l
    clr.b   (PPUADDR_LATCH).l

    ; Build full 16-bit VRAM address
    move.b  (PPUADDR_HI).l,D3
    lsl.w   #8,D3
    move.b  (PPUADDR_LO).l,D3      ; D3 = full NES VRAM addr

    ; Mirror NES VRAM address: $0000-$1FFF = CHR ROM (read only on Genesis)
    ;                          $2000-$2FFF = nametable
    ;                          $3F00-$3FFF = palette
    move.w  D3,(VRAM_ADDR_CURR).l  ; save current address

    ; Check if this is a palette write ($3F00-$3FFF)
    move.w  D3,D4
    andi.w  #$FF00,D4
    cmpi.w  #$3F00,D4
    beq     .palette_addr

    ; Build Genesis VRAM write command for control port
    ; Format: $40000000 | ((addr & $3FFF) << 16) | ($00 | (addr >> 14))
    move.w  D3,D4
    andi.w  #$3FFF,D4               ; mask to 14 bits
    swap    D4                       ; move to high word
    move.w  D3,D4                   ; original addr in low word  
    lsr.w   #8,D4
    lsr.w   #6,D4                   ; addr >> 14 in low word
    ori.l   #$40000000,D4           ; set VRAM write command bits
    move.l  D4,($C00004)            ; send to VDP control port
    rts

.palette_addr:
    ; For palette addresses, set up CRAM write
    ; Genesis CRAM write: $C0000000 | (cram_addr << 16)
    move.w  D3,D4
    andi.w  #$1F,D4                 ; palette entry index (0-31)
    lsl.w   #1,D4                   ; each entry is 2 bytes in CRAM
    swap    D4
    ori.l   #$C0000000,D4
    move.l  D4,($C00004)
    rts

; ═══════════════════════════════════════════════════════════════
; PPU_WRITE_2007 - Replaces: MOVE.B Dn, PPU_REG_$2007
; NES PPUDATA: write byte to current VRAM address, auto-increment
; D0 = data byte
; ═══════════════════════════════════════════════════════════════
PPU_WRITE_2007:
    ; Check if we're writing to palette area
    move.w  (VRAM_ADDR_CURR).l,D3
    move.w  D3,D4
    andi.w  #$FF00,D4
    cmpi.w  #$3F00,D4
    beq     .palette_write

    ; Genesis port: suppress writes to pattern table ($0000-$1FFF)
    ; Tiles are pre-loaded at startup by CHR_VRAM_LOAD; NES tile-copy
    ; routines must be allowed to run (and terminate!) without clobbering them.
    cmpi.w  #$2000,D3
    blo     .skip_write             ; pattern table area: advance counter only

    ; Regular VRAM write - VDP auto-increments by 2 (set in reg $8F)
    ; NES writes bytes, Genesis writes words - pad to word
    move.w  D0,D3
    lsl.w   #8,D3                   ; put byte in high byte of word
    move.w  D3,($C00000)            ; write to VDP data port

    ; Increment address shadow
    move.w  (VRAM_ADDR_CURR).l,D3
    ; Check PPUCTRL bit 2 for increment direction (0=+1, 1=+32)
    btst    #2,(PPUCTRL_SHADOW).l
    beq     .inc_by_1
    addi.w  #32,D3
    bra     .inc_done
.inc_by_1:
    addi.w  #1,D3
.inc_done:
    move.w  D3,(VRAM_ADDR_CURR).l
    rts

.skip_write:
    ; Pattern table write suppressed - just advance address counter
    move.w  (VRAM_ADDR_CURR).l,D3
    btst    #2,(PPUCTRL_SHADOW).l
    beq     .skip_inc_by_1
    addi.w  #32,D3
    bra     .skip_inc_done
.skip_inc_by_1:
    addi.w  #1,D3
.skip_inc_done:
    move.w  D3,(VRAM_ADDR_CURR).l
    rts

.palette_write:
    ; Convert NES palette byte to Genesis BGR555 color
    ; NES palette index is in D0
    bsr     NES_PAL_TO_BGR555       ; converts D0 index → D0 BGR555 value
    move.w  D0,($C00000)            ; write to CRAM via data port
    ; Advance CRAM address
    move.w  (VRAM_ADDR_CURR).l,D3
    addi.w  #1,D3
    move.w  D3,(VRAM_ADDR_CURR).l
    rts


; ═══════════════════════════════════════════════════════════════
; PPU_READ_2007 - Replaces: MOVE.B PPU_REG_$2007, Dn
; NES PPUDATA: read byte from current VRAM address, auto-increment
; Returns result in D0
; ═══════════════════════════════════════════════════════════════
PPU_READ_2007:
    ; Read word from VDP data port, take high byte (NES is byte-wide)
    move.w  ($C00000),D0            ; read from VDP data port
    lsr.w   #8,D0                   ; shift high byte down to low byte
    andi.w  #$00FF,D0               ; mask to byte

    ; Auto-increment address shadow (same logic as write)
    move.w  (VRAM_ADDR_CURR).l,D3
    btst    #2,(PPUCTRL_SHADOW).l
    beq     .read_inc_by_1
    addi.w  #32,D3
    bra     .read_inc_done
.read_inc_by_1:
    addi.w  #1,D3
.read_inc_done:
    move.w  D3,(VRAM_ADDR_CURR).l
    rts

; ═══════════════════════════════════════════════════════════════
; VDP_VBLANK_HANDLER - Genesis vertical interrupt handler
; Replaces NES NMI routine
; Call from your Genesis interrupt vector
; ═══════════════════════════════════════════════════════════════
VDP_VBLANK_HANDLER:
    movem.l D0-D7/A0-A6,-(A7)

    ; acknowledge VBlank interrupt
    move.w  ($C00004),D0

    ; sprite upload
    bsr     VDP_OAM_DMA_TRANSFER

    ; restore scroll from shadows
    move.l  #$BC000003,($C00004)
    moveq   #0,D0
    move.b  (PPUSCROLL_X).l,D0
    neg.w   D0
    move.w  D0,($C00000)

    move.l  #$40004000,($C00004)
    moveq   #0,D0
    move.b  (PPUSCROLL_Y).l,D0
    move.w  D0,($C00000)

    ; run translated Zelda NMI
    jsr     vec_0x01E494_NMI

    movem.l (A7)+,D0-D7/A0-A6
    rte

; ═══════════════════════════════════════════════════════════════
; VDP_OAM_DMA_TRANSFER - Copy sprite data to VRAM sprite table
; NES uses $0200-$02FF for sprite OAM (64 sprites x 4 bytes)
; Genesis sprite table format is different - needs conversion
; ═══════════════════════════════════════════════════════════════
VDP_OAM_DMA_TRANSFER:
    ; Set VRAM write address to sprite table ($D800)
    move.l  #$58000003,($C00004)    ; VRAM write to $D800 (fixed from $70000003)

    ; NES OAM is at $FF0200 in our Genesis RAM mapping
    ; Each NES sprite: byte0=Y, byte1=tile, byte2=attrib, byte3=X
    ; Each Genesis sprite: 4 words (8 bytes) per entry:
    ;   Word 0: Y position (bits 9:0, 128=screen top)
    ;   Word 1: size (high byte, 0=8x8) | link (low byte, next sprite index)
    ;   Word 2: tile attr (priority bit15, palette bits14:13, vflip bit12, hflip bit11, tile bits10:0)
    ;   Word 3: X position (bits 8:0, 128=screen left)
    movea.l #($FF0000+$0200),A1     ; NES OAM base in Genesis RAM
    move.w  #63,D7                  ; 64 sprites (DBRA 63→0)

.sprite_loop:
    move.b  (A1)+,D3                ; NES Y position (OAM Y = sprite top - 1)
    move.b  (A1)+,D4                ; NES tile index
    move.b  (A1)+,D5                ; NES attributes
    move.b  (A1)+,D6                ; NES X position

    ; --- Word 0: Y position ---
    ; Genesis Y=128 = screen pixel row 0. NES OAM Y+1 = actual pixel row.
    ; So genesis_Y = nes_oam_Y + 128 (off-by-one absorbed into screen mapping)
    move.w  D3,D0
    addi.w  #128,D0
    andi.w  #$01FF,D0               ; mask to 9 bits
    move.w  D0,($C00000)

    ; --- Word 1: Size | Link ---
    ; High byte = sprite size: 0x00 = single 8x8 tile
    ; Low byte  = link: index of next sprite (0 = end of chain)
    ; Link = (D7==0) ? 0 : (64-D7)   maps DBRA counter to next-sprite index
    move.w  D7,D0
    beq     .last_sprite
    neg.w   D0
    addi.w  #64,D0                  ; D0 = 64-D7 = index of next sprite
.last_sprite:
    ; high byte stays 0 (size=8x8) since link <= 63 fits in low byte
    move.w  D0,($C00000)

    ; --- Word 2: Tile attribute word ---
    ; bit15    = priority (1 = in front of planes)
    ; bits14:13 = palette (NES attrib bits 1:0)
    ; bit12    = vflip (NES attrib bit7)
    ; bit11    = hflip (NES attrib bit6)
    ; bits10:0  = tile index (NES tile, no VRAM offset yet - BUG D placeholder)
    move.w  D5,D1                   ; NES attributes → D1
    clr.w   D0
    btst    #7,D1
    beq     .no_vflip
    bset    #12,D0                  ; Genesis vflip = bit 12
.no_vflip:
    btst    #6,D1
    beq     .no_hflip
    bset    #11,D0                  ; Genesis hflip = bit 11
.no_hflip:
    ; Palette: NES bits 1:0 → Genesis bits 14:13
    move.w  D1,D2
    andi.w  #$0003,D2
    lsl.w   #8,D2
    lsl.w   #5,D2                   ; total shift = 13, palette lands at bits 14:13
    or.w    D2,D0
    ori.w   #$8000,D0               ; priority bit: always in front
    ; Tile index (NES tile bits 7:0 → Genesis bits 10:0, no VRAM offset yet)
    move.w  D4,D2
    andi.w  #$00FF,D2
    or.w    D2,D0
    move.w  D0,($C00000)

    ; --- Word 3: X position ---
    ; Genesis X=128 = screen pixel column 0
    move.w  D6,D0
    addi.w  #128,D0
    andi.w  #$01FF,D0               ; mask to 9 bits
    move.w  D0,($C00000)

    dbra    D7,.sprite_loop
    rts

; ═══════════════════════════════════════════════════════════════
; VDP_CLEAR_VRAM - Zero out all VRAM
; ═══════════════════════════════════════════════════════════════
VDP_CLEAR_VRAM:
    ; Set VRAM write address to $0000
    move.l  #$40000000,($C00004)
    ; Set auto-increment to 2
    move.w  #$8F02,($C00004)
    ; Write 32KB / 2 = 16384 words of zero
    move.w  #16383,D7
.clear_loop:
    move.w  #0,($C00000)
    dbra    D7,.clear_loop
    rts

; ═══════════════════════════════════════════════════════════════
; VDP_LOAD_NES_PALETTE - Load NES palette approximations into CRAM
; Maps the 64 NES colors to closest Genesis BGR555 equivalents
; ═══════════════════════════════════════════════════════════════
VDP_LOAD_NES_PALETTE:
    ; Set CRAM write address to palette 0
    move.l  #$C0000000,($C00004)
    ; Load 64 NES color approximations (32 colors × 2 palettes)
    lea     NES_PALETTE_DATA,A0
    move.w  #63,D7
.pal_loop:
    move.w  (A0)+,($C00000)
    dbra    D7,.pal_loop
    rts

; ═══════════════════════════════════════════════════════════════
; NES_PAL_TO_BGR555 - Convert NES palette index to Genesis BGR555
; Input:  D0 = NES palette index (0-63)
; Output: D0 = Genesis BGR555 color word
; ═══════════════════════════════════════════════════════════════
NES_PAL_TO_BGR555:
    andi.w  #$3F,D0                 ; mask to 6 bits
    lsl.w   #1,D0                   ; each entry is 2 bytes
    lea     NES_PALETTE_DATA,A0
    move.w  (A0,D0.w),D0
    rts

; ═══════════════════════════════════════════════════════════════
; NES_PALETTE_DATA - 64 NES colors as Genesis BGR555
; Format: 0000 BBB0 GGG0 RRR0 (Genesis uses only 3 bits per channel)
; ═══════════════════════════════════════════════════════════════
NES_PALETTE_DATA:
    ; Row 0: $00-$0F (grays/blacks to light)
    DC.W $0000  ; $00 Black
    DC.W $0888  ; $01 Dark gray
    DC.W $0000  ; $02 Dark blue
    DC.W $0604  ; $03 Dark violet
    DC.W $0400  ; $04 Dark red
    DC.W $0420  ; $05 Dark red-orange
    DC.W $0400  ; $06 Dark orange
    DC.W $0620  ; $07 Brown
    DC.W $0240  ; $08 Dark green-yellow
    DC.W $0040  ; $09 Dark green
    DC.W $0060  ; $0A Dark teal
    DC.W $0046  ; $0B Dark cyan
    DC.W $0444  ; $0C Dark teal-gray
    DC.W $0000  ; $0D Black (unused)
    DC.W $0000  ; $0E Black (unused)
    DC.W $0000  ; $0F Black (unused)
    ; Row 1: $10-$1F (medium colors)
    DC.W $0AAA  ; $10 Medium gray
    DC.W $0E00  ; $11 Medium blue
    DC.W $0C04  ; $12 Medium indigo
    DC.W $0A06  ; $13 Medium violet
    DC.W $0808  ; $14 Medium purple-red
    DC.W $0808  ; $15 Medium red
    DC.W $0608  ; $16 Medium orange-red
    DC.W $0446  ; $17 Medium brown
    DC.W $0262  ; $18 Olive
    DC.W $0060  ; $19 Medium green
    DC.W $0068  ; $1A Medium teal-green
    DC.W $0068  ; $1B Medium teal
    DC.W $0086  ; $1C Medium cyan
    DC.W $0000  ; $1D Black
    DC.W $0000  ; $1E Black
    DC.W $0000  ; $1F Black
    ; Row 2: $20-$2F (light colors)
    DC.W $0EEE  ; $20 White
    DC.W $0EE2  ; $21 Light blue
    DC.W $0EE6  ; $22 Light indigo
    DC.W $0EC8  ; $23 Light violet
    DC.W $0EAA  ; $24 Light pink
    DC.W $0EAA  ; $25 Light red
    DC.W $0EA4  ; $26 Light orange
    DC.W $0EA0  ; $27 Light yellow-orange
    DC.W $0CE0  ; $28 Light yellow
    DC.W $04E0  ; $29 Light green
    DC.W $04E4  ; $2A Light teal
    DC.W $04EE  ; $2B Light cyan
    DC.W $006E  ; $2C Light sky blue
    DC.W $0000  ; $2D Black
    DC.W $0000  ; $2E Black
    DC.W $0000  ; $2F Black
    ; Row 3: $30-$3F (pastels/whites)
    DC.W $0EEE  ; $30 White
    DC.W $0EEE  ; $31 Light blue-white
    DC.W $0EEE  ; $32 Light violet-white
    DC.W $0EEE  ; $33 Light pink-white
    DC.W $0EEE  ; $34 Light rose-white
    DC.W $0EEE  ; $35 Light orange-white
    DC.W $0EEE  ; $36 Light peach
    DC.W $0EEE  ; $37 Light cream
    DC.W $0EEE  ; $38 Light yellow-white
    DC.W $0EEE  ; $39 Light green-white
    DC.W $0EEE  ; $3A Light mint
    DC.W $0EEE  ; $3B Light aqua
    DC.W $0EEE  ; $3C Light sky
    DC.W $0000  ; $3D Black
    DC.W $0000  ; $3E Black
    DC.W $0000  ; $3F Black
